"use strict";
(() => {
  // packages/tools-core/dist/jsonFormatter.js
  function formatJSON(raw) {
    if (typeof raw !== "string") {
      return {
        success: false,
        data: "",
        error: "Input must be a string."
      };
    }
    const trimmed = raw.trim();
    if (trimmed.length === 0) {
      return {
        success: false,
        data: "",
        error: "Input is empty."
      };
    }
    try {
      const parsed = JSON.parse(trimmed);
      const formatted = JSON.stringify(parsed, null, 2);
      return {
        success: true,
        data: formatted
      };
    } catch (err) {
      const message = err instanceof Error ? err.message : "Invalid JSON input.";
      return {
        success: false,
        data: "",
        error: message
      };
    }
  }
  function minifyJSON(raw) {
    if (typeof raw !== "string" || raw.trim().length === 0) {
      return {
        success: false,
        data: "",
        error: "Input must be a non-empty string."
      };
    }
    try {
      const parsed = JSON.parse(raw.trim());
      const minified = JSON.stringify(parsed);
      return {
        success: true,
        data: minified
      };
    } catch (err) {
      const message = err instanceof Error ? err.message : "Invalid JSON input.";
      return {
        success: false,
        data: "",
        error: message
      };
    }
  }

  // packages/tools-core/dist/caseConverter.js
  function toSnakeCase(input) {
    if (typeof input !== "string")
      return "";
    return input.replace(/([a-z])([A-Z])/g, "$1_$2").replace(/[\s-]+/g, "_").toLowerCase();
  }
  function toCamelCase(input) {
    if (typeof input !== "string")
      return "";
    return input.replace(/(?:^\w|[A-Z]|[\s-_]\w)/g, (match, index) => index === 0 ? match.toLowerCase() : match.toUpperCase()).replace(/[\s-_]+/g, "");
  }
  function toKebabCase(input) {
    if (typeof input !== "string")
      return "";
    return input.replace(/([a-z])([A-Z])/g, "$1-$2").replace(/[\s_]+/g, "-").toLowerCase();
  }
  function toPascalCase(input) {
    if (typeof input !== "string")
      return "";
    const camel = toCamelCase(input);
    return camel.charAt(0).toUpperCase() + camel.slice(1);
  }

  // packages/tools-core/dist/base64.js
  function encodeBase64(str) {
    try {
      return btoa(unescape(encodeURIComponent(str)));
    } catch (err) {
      throw new Error("Failed to encode input to Base64");
    }
  }
  function decodeBase64(str) {
    const cleaned = str.replace(/\s+/g, "");
    try {
      return decodeURIComponent(escape(atob(cleaned)));
    } catch (err) {
      throw new Error("Invalid Base64 input sequence");
    }
  }

  // packages/tools-core/dist/diffChecker.js
  function computeLineDiff(original, modified) {
    const leftLines = original.split(/\r?\n/);
    const rightLines = modified.split(/\r?\n/);
    const m = leftLines.length;
    const n = rightLines.length;
    if (m > 3e3 || n > 3e3) {
      throw new Error("Input text is too long. Please limit text blocks to 3,000 lines.");
    }
    const dp = Array(m + 1).fill(null).map(() => Array(n + 1).fill(0));
    for (let i2 = 1; i2 <= m; i2++) {
      for (let j2 = 1; j2 <= n; j2++) {
        if (leftLines[i2 - 1] === rightLines[j2 - 1]) {
          dp[i2][j2] = dp[i2 - 1][j2 - 1] + 1;
        } else {
          dp[i2][j2] = Math.max(dp[i2 - 1][j2], dp[i2][j2 - 1]);
        }
      }
    }
    const rawRows = [];
    let i = m;
    let j = n;
    while (i > 0 || j > 0) {
      if (i > 0 && j > 0 && leftLines[i - 1] === rightLines[j - 1]) {
        rawRows.unshift({
          left: { lineNum: i, content: leftLines[i - 1], type: "unchanged" },
          right: { lineNum: j, content: rightLines[j - 1], type: "unchanged" }
        });
        i--;
        j--;
      } else if (j > 0 && (i === 0 || dp[i][j - 1] >= dp[i - 1][j])) {
        rawRows.unshift({
          right: { lineNum: j, content: rightLines[j - 1], type: "added" }
        });
        j--;
      } else {
        rawRows.unshift({
          left: { lineNum: i, content: leftLines[i - 1], type: "removed" }
        });
        i--;
      }
    }
    return alignDiffRows(rawRows);
  }
  function alignDiffRows(rows) {
    const aligned = [];
    let i = 0;
    while (i < rows.length) {
      const current = rows[i];
      const next = rows[i + 1];
      if (current.left && current.left.type === "removed" && !current.right && next && next.right && next.right.type === "added" && !next.left) {
        aligned.push({
          left: current.left,
          right: next.right
        });
        i += 2;
      } else {
        aligned.push(current);
        i += 1;
      }
    }
    return aligned;
  }

  // packages/tools-core/dist/jwtDecoder.js
  function base64UrlToBase64(base64url) {
    let base64 = base64url.replace(/-/g, "+").replace(/_/g, "/");
    while (base64.length % 4) {
      base64 += "=";
    }
    return base64;
  }
  function safeJsonParse(str) {
    try {
      return JSON.parse(str);
    } catch (_) {
      return null;
    }
  }
  function decodeJwtToken(token) {
    const cleanedToken = token.trim();
    const parts = cleanedToken.split(".");
    if (parts.length !== 3) {
      return {
        header: null,
        payload: null,
        signature: "",
        isExpired: false,
        validFormat: false,
        error: "Invalid JWT format. A token must consist of 3 parts separated by dots."
      };
    }
    try {
      const [headerB64, payloadB64, signature] = parts;
      const decodedHeaderStr = decodeBase64(base64UrlToBase64(headerB64));
      const decodedPayloadStr = decodeBase64(base64UrlToBase64(payloadB64));
      const header = safeJsonParse(decodedHeaderStr);
      const payload = safeJsonParse(decodedPayloadStr);
      if (!header || !payload) {
        return {
          header,
          payload,
          signature,
          isExpired: false,
          validFormat: false,
          error: "Failed to parse JWT segments as JSON."
        };
      }
      let isExpired = false;
      let expiresAt;
      let issuedAt;
      if (payload.exp && typeof payload.exp === "number") {
        const expMs = payload.exp * 1e3;
        isExpired = Date.now() > expMs;
        expiresAt = new Date(expMs).toISOString();
      }
      if (payload.iat && typeof payload.iat === "number") {
        issuedAt = new Date(payload.iat * 1e3).toISOString();
      }
      return {
        header,
        payload,
        signature,
        isExpired,
        expiresAt,
        issuedAt,
        validFormat: true
      };
    } catch (err) {
      return {
        header: null,
        payload: null,
        signature: parts[2] || "",
        isExpired: false,
        validFormat: false,
        error: err.message || "Failed to decode JWT base64 segments."
      };
    }
  }

  // packages/tools-core/dist/urlUtility.js
  function encodeUrlString(text) {
    try {
      return encodeURIComponent(text);
    } catch (_) {
      return text;
    }
  }
  function decodeUrlString(text) {
    try {
      return decodeURIComponent(text.replace(/\+/g, " "));
    } catch (_) {
      return text;
    }
  }

  // apps/extension-zerowebtools/popup.js
  document.addEventListener("DOMContentLoaded", () => {
    const tabs = document.querySelectorAll(".tab");
    const panels = document.querySelectorAll(".panel");
    tabs.forEach((tab) => {
      tab.addEventListener("click", () => {
        tabs.forEach((t) => t.classList.remove("active"));
        panels.forEach((p) => p.classList.remove("active"));
        tab.classList.add("active");
        const targetPanel = document.getElementById(tab.getAttribute("data-panel"));
        if (targetPanel) targetPanel.classList.add("active");
      });
    });
    document.querySelectorAll(".copy-btn").forEach((btn) => {
      btn.addEventListener("click", () => {
        const targetId = btn.getAttribute("data-target");
        const targetEl = document.getElementById(targetId);
        if (targetEl) {
          const textToCopy = targetEl.value !== void 0 ? targetEl.value : targetEl.textContent;
          navigator.clipboard.writeText(textToCopy).then(() => {
            const originalText = btn.textContent;
            btn.textContent = "Copied!";
            btn.style.color = "var(--success)";
            setTimeout(() => {
              btn.textContent = originalText;
              btn.style.color = "";
            }, 1500);
          });
        }
      });
    });
    const jsonInput = document.getElementById("json-input");
    const jsonOutput = document.getElementById("json-output-text");
    document.getElementById("json-format").addEventListener("click", () => {
      try {
        const result = formatJSON(jsonInput.value);
        if (result.success) {
          jsonOutput.textContent = result.data;
          jsonOutput.style.color = "var(--ink)";
        } else {
          jsonOutput.textContent = "Invalid JSON: " + (result.error || "Unknown error");
          jsonOutput.style.color = "var(--error)";
        }
      } catch (e) {
        jsonOutput.textContent = "Invalid JSON: " + e.message;
        jsonOutput.style.color = "var(--error)";
      }
    });
    document.getElementById("json-minify").addEventListener("click", () => {
      try {
        const result = minifyJSON(jsonInput.value);
        if (result.success) {
          jsonOutput.textContent = result.data;
          jsonOutput.style.color = "var(--ink)";
        } else {
          jsonOutput.textContent = "Invalid JSON: " + (result.error || "Unknown error");
          jsonOutput.style.color = "var(--error)";
        }
      } catch (e) {
        jsonOutput.textContent = "Invalid JSON: " + e.message;
        jsonOutput.style.color = "var(--error)";
      }
    });
    document.getElementById("json-clear").addEventListener("click", () => {
      jsonInput.value = "";
      jsonOutput.textContent = "Formatted output will appear here.";
      jsonOutput.style.color = "var(--ink-muted)";
    });
    const caseInput = document.getElementById("case-input");
    const updateCases = () => {
      const val = caseInput.value || "hello world example";
      document.getElementById("out-camel").textContent = toCamelCase(val);
      document.getElementById("out-snake").textContent = toSnakeCase(val);
      document.getElementById("out-kebab").textContent = toKebabCase(val);
      document.getElementById("out-pascal").textContent = toPascalCase(val);
    };
    caseInput.addEventListener("input", updateCases);
    updateCases();
    const diffOrig = document.getElementById("diff-original");
    const diffMod = document.getElementById("diff-modified");
    const diffOutput = document.getElementById("diff-output");
    document.getElementById("diff-analyze").addEventListener("click", () => {
      try {
        const rows = computeLineDiff(diffOrig.value, diffMod.value);
        diffOutput.innerHTML = "";
        rows.forEach((row) => {
          if (row.left && row.left.type === "removed") {
            const div = document.createElement("div");
            div.className = "diff-row removed";
            div.textContent = "- " + row.left.content;
            diffOutput.appendChild(div);
          }
          if (row.right && row.right.type === "added") {
            const div = document.createElement("div");
            div.className = "diff-row added";
            div.textContent = "+ " + row.right.content;
            diffOutput.appendChild(div);
          }
          if (row.left && row.left.type === "unchanged") {
            const div = document.createElement("div");
            div.className = "diff-row";
            div.textContent = "  " + row.left.content;
            diffOutput.appendChild(div);
          }
        });
        diffOutput.style.color = "var(--ink)";
      } catch (e) {
        diffOutput.textContent = e.message;
        diffOutput.style.color = "var(--error)";
      }
    });
    const jwtInput = document.getElementById("jwt-input");
    const jwtHeader = document.getElementById("jwt-header-text");
    const jwtPayload = document.getElementById("jwt-payload-text");
    jwtInput.addEventListener("input", () => {
      const token = jwtInput.value.trim();
      if (!token) {
        jwtHeader.textContent = "";
        jwtPayload.textContent = "";
        return;
      }
      const result = decodeJwtToken(token);
      if (result.isValid && result.decoded) {
        jwtHeader.textContent = JSON.stringify(result.decoded.header, null, 2);
        jwtHeader.style.color = "var(--ink)";
        jwtPayload.textContent = JSON.stringify(result.decoded.payload, null, 2);
        jwtPayload.style.color = "var(--ink)";
      } else {
        jwtHeader.textContent = "Invalid Token";
        jwtHeader.style.color = "var(--error)";
        jwtPayload.textContent = result.error || "Malformed JWT structure";
        jwtPayload.style.color = "var(--error)";
      }
    });
    const base64Input = document.getElementById("base64-input");
    const base64Output = document.getElementById("base64-output-text");
    document.getElementById("base64-encode").addEventListener("click", () => {
      base64Output.textContent = encodeBase64(base64Input.value);
      base64Output.style.color = "var(--ink)";
    });
    document.getElementById("base64-decode").addEventListener("click", () => {
      try {
        base64Output.textContent = decodeBase64(base64Input.value);
        base64Output.style.color = "var(--ink)";
      } catch (e) {
        base64Output.textContent = "Invalid Base64 string.";
        base64Output.style.color = "var(--error)";
      }
    });
    const urlInput = document.getElementById("url-input");
    const urlOutput = document.getElementById("url-output-text");
    document.getElementById("url-encode").addEventListener("click", () => {
      urlOutput.textContent = encodeUrlString(urlInput.value);
      urlOutput.style.color = "var(--ink)";
    });
    document.getElementById("url-decode").addEventListener("click", () => {
      try {
        urlOutput.textContent = decodeUrlString(urlInput.value);
        urlOutput.style.color = "var(--ink)";
      } catch (e) {
        urlOutput.textContent = "Invalid URL encoding.";
        urlOutput.style.color = "var(--error)";
      }
    });
  });
})();
