"use strict";
(() => {
  // packages/tools-core/dist/jsonFormatter.js
  function formatJSON(raw) {
    if (typeof raw !== "string") {
      return {
        success: false,
        data: "",
        error: "Input must be a string."
      };
    }
    const trimmed = raw.trim();
    if (trimmed.length === 0) {
      return {
        success: false,
        data: "",
        error: "Input is empty."
      };
    }
    try {
      const parsed = JSON.parse(trimmed);
      const formatted = JSON.stringify(parsed, null, 2);
      return {
        success: true,
        data: formatted
      };
    } catch (err) {
      const message = err instanceof Error ? err.message : "Invalid JSON input.";
      return {
        success: false,
        data: "",
        error: message
      };
    }
  }
  function minifyJSON(raw) {
    if (typeof raw !== "string" || raw.trim().length === 0) {
      return {
        success: false,
        data: "",
        error: "Input must be a non-empty string."
      };
    }
    try {
      const parsed = JSON.parse(raw.trim());
      const minified = JSON.stringify(parsed);
      return {
        success: true,
        data: minified
      };
    } catch (err) {
      const message = err instanceof Error ? err.message : "Invalid JSON input.";
      return {
        success: false,
        data: "",
        error: message
      };
    }
  }

  // packages/tools-core/dist/caseConverter.js
  function toSnakeCase(input) {
    if (typeof input !== "string")
      return "";
    return input.replace(/([a-z])([A-Z])/g, "$1_$2").replace(/[\s-]+/g, "_").toLowerCase();
  }
  function toCamelCase(input) {
    if (typeof input !== "string")
      return "";
    return input.replace(/(?:^\w|[A-Z]|[\s-_]\w)/g, (match, index) => index === 0 ? match.toLowerCase() : match.toUpperCase()).replace(/[\s-_]+/g, "");
  }
  function toKebabCase(input) {
    if (typeof input !== "string")
      return "";
    return input.replace(/([a-z])([A-Z])/g, "$1-$2").replace(/[\s_]+/g, "-").toLowerCase();
  }
  function toPascalCase(input) {
    if (typeof input !== "string")
      return "";
    const camel = toCamelCase(input);
    return camel.charAt(0).toUpperCase() + camel.slice(1);
  }

  // packages/tools-core/dist/jsonParserEngine.js
  function getType(val) {
    if (val === null)
      return "null";
    if (Array.isArray(val))
      return "array";
    return typeof val;
  }
  function formatValue(val) {
    if (val === null)
      return "null";
    if (typeof val === "string")
      return `"${val}"`;
    if (typeof val === "boolean" || typeof val === "number")
      return String(val);
    if (Array.isArray(val))
      return `Array(${val.length})`;
    if (typeof val === "object")
      return `{${Object.keys(val).length} keys}`;
    return String(val);
  }
  function buildTree(val, parentId, key, depth, counter) {
    const idx = counter.idx++;
    const id = parentId ? `${parentId}.${key || idx}` : "root";
    const type = getType(val);
    const expandable = type === "object" || type === "array";
    const childIds = [];
    const node = {
      id,
      key,
      value: formatValue(val),
      type,
      depth,
      expandable,
      childCount: 0,
      children: childIds,
      parent: parentId
    };
    const allNodes = [node];
    if (type === "object" && val !== null && typeof val === "object" && !Array.isArray(val)) {
      const entries = Object.entries(val);
      node.childCount = entries.length;
      for (const [k, v] of entries) {
        const [childNodes] = buildTree(v, id, k, depth + 1, counter);
        const firstChild = childNodes[0];
        childIds.push(firstChild.id);
        node.children = childIds;
        allNodes.push(...childNodes);
      }
    } else if (type === "array" && Array.isArray(val)) {
      node.childCount = val.length;
      for (let i = 0; i < val.length; i++) {
        const [childNodes] = buildTree(val[i], id, String(i), depth + 1, counter);
        const firstChild = childNodes[0];
        childIds.push(firstChild.id);
        node.children = childIds;
        allNodes.push(...childNodes);
      }
    }
    return [allNodes, id];
  }
  function maxDepth(tree, rootId) {
    const map = new Map(tree.map((n) => [n.id, n]));
    let max = 0;
    for (const node of tree) {
      if (node.id !== rootId) {
        let d = 0;
        let cur = node.parent;
        while (cur && map.has(cur)) {
          d++;
          cur = map.get(cur).parent;
        }
        if (d > max)
          max = d;
      }
    }
    return max;
  }
  function parseJsonToTree(raw) {
    const trimmed = (raw ?? "").trim();
    if (!trimmed) {
      return {
        success: false,
        tree: [],
        rootId: "",
        error: "Input is empty.",
        stats: { charCount: 0, lineCount: 0, nodeCount: 0, depth: 0 }
      };
    }
    let parsed;
    try {
      parsed = JSON.parse(trimmed);
    } catch (err) {
      return {
        success: false,
        tree: [],
        rootId: "",
        error: err instanceof Error ? err.message : "Invalid JSON.",
        stats: { charCount: trimmed.length, lineCount: trimmed.split("\n").length, nodeCount: 0, depth: 0 }
      };
    }
    const [tree, rootId] = buildTree(parsed, "", "", 0, { idx: 0 });
    const depth = maxDepth(tree, rootId);
    return {
      success: true,
      tree,
      rootId,
      stats: {
        charCount: trimmed.length,
        lineCount: trimmed.split("\n").length,
        nodeCount: tree.length,
        depth
      }
    };
  }

  // packages/tools-core/dist/base64.js
  function encodeBase64(str) {
    try {
      return btoa(unescape(encodeURIComponent(str)));
    } catch (err) {
      throw new Error("Failed to encode input to Base64");
    }
  }
  function decodeBase64(str) {
    const cleaned = str.replace(/\s+/g, "");
    try {
      return decodeURIComponent(escape(atob(cleaned)));
    } catch (err) {
      throw new Error("Invalid Base64 input sequence");
    }
  }

  // packages/tools-core/dist/diffChecker.js
  function computeLineDiff(original, modified) {
    const leftLines = original.split(/\r?\n/);
    const rightLines = modified.split(/\r?\n/);
    const m = leftLines.length;
    const n = rightLines.length;
    if (m > 3e3 || n > 3e3) {
      throw new Error("Input text is too long. Please limit text blocks to 3,000 lines.");
    }
    const dp = Array(m + 1).fill(null).map(() => Array(n + 1).fill(0));
    for (let i2 = 1; i2 <= m; i2++) {
      for (let j2 = 1; j2 <= n; j2++) {
        if (leftLines[i2 - 1] === rightLines[j2 - 1]) {
          dp[i2][j2] = dp[i2 - 1][j2 - 1] + 1;
        } else {
          dp[i2][j2] = Math.max(dp[i2 - 1][j2], dp[i2][j2 - 1]);
        }
      }
    }
    const rawRows = [];
    let i = m;
    let j = n;
    while (i > 0 || j > 0) {
      if (i > 0 && j > 0 && leftLines[i - 1] === rightLines[j - 1]) {
        rawRows.unshift({
          left: { lineNum: i, content: leftLines[i - 1], type: "unchanged" },
          right: { lineNum: j, content: rightLines[j - 1], type: "unchanged" }
        });
        i--;
        j--;
      } else if (j > 0 && (i === 0 || dp[i][j - 1] >= dp[i - 1][j])) {
        rawRows.unshift({
          right: { lineNum: j, content: rightLines[j - 1], type: "added" }
        });
        j--;
      } else {
        rawRows.unshift({
          left: { lineNum: i, content: leftLines[i - 1], type: "removed" }
        });
        i--;
      }
    }
    return alignDiffRows(rawRows);
  }
  function alignDiffRows(rows) {
    const aligned = [];
    let i = 0;
    while (i < rows.length) {
      const current = rows[i];
      const next = rows[i + 1];
      if (current.left && current.left.type === "removed" && !current.right && next && next.right && next.right.type === "added" && !next.left) {
        aligned.push({
          left: current.left,
          right: next.right
        });
        i += 2;
      } else {
        aligned.push(current);
        i += 1;
      }
    }
    return aligned;
  }

  // packages/tools-core/dist/jwtDecoder.js
  function base64UrlToBase64(base64url) {
    let base64 = base64url.replace(/-/g, "+").replace(/_/g, "/");
    while (base64.length % 4) {
      base64 += "=";
    }
    return base64;
  }
  function safeJsonParse(str) {
    try {
      return JSON.parse(str);
    } catch (_) {
      return null;
    }
  }
  function decodeJwtToken(token) {
    const cleanedToken = token.trim();
    const parts = cleanedToken.split(".");
    if (parts.length !== 3) {
      return {
        header: null,
        payload: null,
        signature: "",
        isExpired: false,
        validFormat: false,
        error: "Invalid JWT format. A token must consist of 3 parts separated by dots."
      };
    }
    try {
      const [headerB64, payloadB64, signature] = parts;
      const decodedHeaderStr = decodeBase64(base64UrlToBase64(headerB64));
      const decodedPayloadStr = decodeBase64(base64UrlToBase64(payloadB64));
      const header = safeJsonParse(decodedHeaderStr);
      const payload = safeJsonParse(decodedPayloadStr);
      if (!header || !payload) {
        return {
          header,
          payload,
          signature,
          isExpired: false,
          validFormat: false,
          error: "Failed to parse JWT segments as JSON."
        };
      }
      let isExpired = false;
      let expiresAt;
      let issuedAt;
      if (payload.exp && typeof payload.exp === "number") {
        const expMs = payload.exp * 1e3;
        isExpired = Date.now() > expMs;
        expiresAt = new Date(expMs).toISOString();
      }
      if (payload.iat && typeof payload.iat === "number") {
        issuedAt = new Date(payload.iat * 1e3).toISOString();
      }
      return {
        header,
        payload,
        signature,
        isExpired,
        expiresAt,
        issuedAt,
        validFormat: true
      };
    } catch (err) {
      return {
        header: null,
        payload: null,
        signature: parts[2] || "",
        isExpired: false,
        validFormat: false,
        error: err.message || "Failed to decode JWT base64 segments."
      };
    }
  }

  // packages/tools-core/dist/urlUtility.js
  function encodeUrlString(text) {
    try {
      return encodeURIComponent(text);
    } catch (_) {
      return text;
    }
  }
  function decodeUrlString(text) {
    try {
      return decodeURIComponent(text.replace(/\+/g, " "));
    } catch (_) {
      return text;
    }
  }

  // apps/extensions/developertools/popup.js
  document.addEventListener("DOMContentLoaded", () => {
    const tabs = document.querySelectorAll(".tab");
    const panels = document.querySelectorAll(".panel");
    tabs.forEach((tab) => {
      tab.addEventListener("click", () => {
        tabs.forEach((t) => t.classList.remove("active"));
        panels.forEach((p) => p.classList.remove("active"));
        tab.classList.add("active");
        const targetPanel = document.getElementById(tab.getAttribute("data-panel"));
        if (targetPanel) targetPanel.classList.add("active");
      });
    });
    document.querySelectorAll(".copy-btn").forEach((btn) => {
      btn.addEventListener("click", () => {
        const targetId = btn.getAttribute("data-target");
        const targetEl = document.getElementById(targetId);
        if (targetEl) {
          const textToCopy = targetEl.value !== void 0 ? targetEl.value : targetEl.textContent;
          navigator.clipboard.writeText(textToCopy).then(() => {
            const originalText = btn.textContent;
            btn.textContent = "Copied!";
            btn.style.color = "var(--success)";
            setTimeout(() => {
              btn.textContent = originalText;
              btn.style.color = "";
            }, 1500);
          });
        }
      });
    });
    const jsonInput = document.getElementById("json-input");
    const jsonTreeContainer = document.getElementById("json-tree-container");
    const jsonCopyBtn = document.getElementById("json-copy-btn");
    let latestFormattedJson = "";
    function renderTreeNode(node, nodeMap) {
      const container = document.createElement("div");
      container.className = "tree-node-wrapper";
      const row = document.createElement("div");
      row.className = "tree-row";
      const indent = node.depth * 12;
      row.style.paddingLeft = indent + "px";
      const arrow = document.createElement("span");
      arrow.className = "tree-arrow";
      if (node.expandable) {
        const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
        svg.setAttribute("width", "6");
        svg.setAttribute("height", "6");
        svg.setAttribute("viewBox", "0 0 10 10");
        svg.setAttribute("fill", "currentColor");
        const path = document.createElementNS("http://www.w3.org/2000/svg", "path");
        path.setAttribute("d", "M3 1l5 4-5 4V1z");
        svg.appendChild(path);
        arrow.appendChild(svg);
      }
      row.appendChild(arrow);
      if (node.key !== "") {
        const keySpan = document.createElement("span");
        keySpan.className = "tree-key";
        keySpan.textContent = node.key;
        row.appendChild(keySpan);
        const colon = document.createElement("span");
        colon.style.color = "var(--ink-muted)";
        colon.textContent = ":";
        row.appendChild(colon);
      }
      const valSpan = document.createElement("span");
      valSpan.className = `tree-val-${node.type}`;
      valSpan.setAttribute("data-type", node.type);
      valSpan.setAttribute("data-count", node.childCount);
      if (node.expandable) {
        valSpan.classList.add("tree-val-bracket");
        valSpan.textContent = node.type === "array" ? `[${node.childCount}]` : `{${node.childCount}}`;
      } else {
        valSpan.textContent = node.value;
      }
      row.appendChild(valSpan);
      container.appendChild(row);
      if (node.expandable && node.children.length > 0) {
        const childrenContainer = document.createElement("div");
        childrenContainer.className = "tree-children";
        node.children.forEach((childId) => {
          const childNode = nodeMap.get(childId);
          if (childNode) {
            childrenContainer.appendChild(renderTreeNode(childNode, nodeMap));
          }
        });
        container.appendChild(childrenContainer);
        row.addEventListener("click", (e) => {
          e.stopPropagation();
          const currentlyExpanded = childrenContainer.classList.contains("expanded");
          if (currentlyExpanded) {
            childrenContainer.classList.remove("expanded");
            arrow.classList.remove("expanded");
            valSpan.style.display = "";
            valSpan.textContent = node.type === "array" ? `[${node.childCount}]` : `{${node.childCount}}`;
          } else {
            childrenContainer.classList.add("expanded");
            arrow.classList.add("expanded");
            valSpan.style.display = "none";
          }
        });
      }
      return container;
    }
    const updateTreeView = () => {
      const val = jsonInput.value.trim();
      if (!val) {
        jsonTreeContainer.textContent = "Interactive tree explorer will appear here.";
        jsonTreeContainer.style.color = "var(--ink-muted)";
        latestFormattedJson = "";
        return;
      }
      const parseResult = parseJsonToTree(val);
      if (parseResult.success) {
        const nodeMap = new Map(parseResult.tree.map((n) => [n.id, n]));
        jsonTreeContainer.textContent = "";
        const rootNode = nodeMap.get("root");
        if (rootNode) {
          try {
            const res = formatJSON(val);
            if (res.success) latestFormattedJson = res.data;
          } catch (_) {
          }
          if (rootNode.expandable) {
            const openBracket = document.createElement("div");
            openBracket.className = "tree-row";
            openBracket.style.color = "var(--ink-muted)";
            openBracket.style.fontWeight = "600";
            openBracket.textContent = rootNode.type === "array" ? "[" : "{";
            jsonTreeContainer.appendChild(openBracket);
            const childrenContainer = document.createElement("div");
            childrenContainer.className = "tree-children expanded";
            if (rootNode.children.length > 0) {
              rootNode.children.forEach((childId) => {
                const childNode = nodeMap.get(childId);
                if (childNode) {
                  childrenContainer.appendChild(renderTreeNode(childNode, nodeMap));
                }
              });
            }
            jsonTreeContainer.appendChild(childrenContainer);
            const closeBracket = document.createElement("div");
            closeBracket.className = "tree-row";
            closeBracket.style.color = "var(--ink-muted)";
            closeBracket.style.fontWeight = "600";
            closeBracket.textContent = rootNode.type === "array" ? "]" : "}";
            jsonTreeContainer.appendChild(closeBracket);
          } else {
            jsonTreeContainer.appendChild(renderTreeNode(rootNode, nodeMap));
          }
        }
        jsonTreeContainer.style.color = "var(--ink)";
      } else {
        jsonTreeContainer.textContent = "Invalid JSON: " + (parseResult.error || "Unknown error");
        jsonTreeContainer.style.color = "var(--error)";
        latestFormattedJson = "";
      }
    };
    jsonInput.addEventListener("input", updateTreeView);
    document.getElementById("json-format").addEventListener("click", () => {
      try {
        const result = formatJSON(jsonInput.value);
        if (result.success) {
          latestFormattedJson = result.data;
          updateTreeView();
        } else {
          jsonTreeContainer.textContent = "Invalid JSON: " + (result.error || "Unknown error");
          jsonTreeContainer.style.color = "var(--error)";
        }
      } catch (e) {
        jsonTreeContainer.textContent = "Invalid JSON: " + e.message;
        jsonTreeContainer.style.color = "var(--error)";
      }
    });
    document.getElementById("json-minify").addEventListener("click", () => {
      try {
        const result = minifyJSON(jsonInput.value);
        if (result.success) {
          latestFormattedJson = result.data;
          jsonTreeContainer.textContent = "";
          const pre = document.createElement("pre");
          pre.style.whiteSpace = "pre-wrap";
          pre.style.wordBreak = "break-all";
          pre.style.fontFamily = "inherit";
          pre.style.margin = "0";
          pre.style.color = "var(--ink)";
          pre.textContent = result.data;
          jsonTreeContainer.appendChild(pre);
          jsonTreeContainer.style.color = "var(--ink)";
        } else {
          jsonTreeContainer.textContent = "Invalid JSON: " + (result.error || "Unknown error");
          jsonTreeContainer.style.color = "var(--error)";
        }
      } catch (e) {
        jsonTreeContainer.textContent = "Invalid JSON: " + e.message;
        jsonTreeContainer.style.color = "var(--error)";
      }
    });
    document.getElementById("json-expand-all").addEventListener("click", () => {
      const wrappers = jsonTreeContainer.querySelectorAll(".tree-node-wrapper");
      wrappers.forEach((wrap) => {
        const children = wrap.querySelector(".tree-children");
        const arrow = wrap.querySelector(".tree-arrow");
        const val = wrap.querySelector(".tree-val-bracket");
        if (children && arrow && val) {
          children.classList.add("expanded");
          arrow.classList.add("expanded");
          val.style.display = "none";
        }
      });
    });
    document.getElementById("json-collapse-all").addEventListener("click", () => {
      const wrappers = jsonTreeContainer.querySelectorAll(".tree-node-wrapper");
      wrappers.forEach((wrap) => {
        const children = wrap.querySelector(".tree-children");
        const arrow = wrap.querySelector(".tree-arrow");
        const val = wrap.querySelector(".tree-val-bracket");
        if (children && arrow && val) {
          children.classList.remove("expanded");
          arrow.classList.remove("expanded");
          val.style.display = "";
          const nodeType = val.getAttribute("data-type");
          const childCount = val.getAttribute("data-count");
          val.textContent = nodeType === "array" ? `[${childCount}]` : `{${childCount}}`;
        }
      });
    });
    document.getElementById("json-clear").addEventListener("click", () => {
      jsonInput.value = "";
      jsonTreeContainer.textContent = "Interactive tree explorer will appear here.";
      jsonTreeContainer.style.color = "var(--ink-muted)";
      latestFormattedJson = "";
    });
    jsonCopyBtn.addEventListener("click", () => {
      const textToCopy = latestFormattedJson || jsonInput.value;
      if (textToCopy) {
        navigator.clipboard.writeText(textToCopy).then(() => {
          const originalText = jsonCopyBtn.textContent;
          jsonCopyBtn.textContent = "Copied!";
          jsonCopyBtn.style.color = "var(--success)";
          setTimeout(() => {
            jsonCopyBtn.textContent = originalText;
            jsonCopyBtn.style.color = "";
          }, 1500);
        });
      }
    });
    updateTreeView();
    const caseInput = document.getElementById("case-input");
    const updateCases = () => {
      const val = caseInput.value || "hello world example";
      document.getElementById("out-camel").textContent = toCamelCase(val);
      document.getElementById("out-snake").textContent = toSnakeCase(val);
      document.getElementById("out-kebab").textContent = toKebabCase(val);
      document.getElementById("out-pascal").textContent = toPascalCase(val);
    };
    caseInput.addEventListener("input", updateCases);
    updateCases();
    const diffOrig = document.getElementById("diff-original");
    const diffMod = document.getElementById("diff-modified");
    const diffOutput = document.getElementById("diff-output");
    document.getElementById("diff-analyze").addEventListener("click", () => {
      try {
        const rows = computeLineDiff(diffOrig.value, diffMod.value);
        diffOutput.textContent = "";
        rows.forEach((row) => {
          if (row.left && row.left.type === "removed") {
            const div = document.createElement("div");
            div.className = "diff-row removed";
            div.textContent = "- " + row.left.content;
            diffOutput.appendChild(div);
          }
          if (row.right && row.right.type === "added") {
            const div = document.createElement("div");
            div.className = "diff-row added";
            div.textContent = "+ " + row.right.content;
            diffOutput.appendChild(div);
          }
          if (row.left && row.left.type === "unchanged") {
            const div = document.createElement("div");
            div.className = "diff-row";
            div.textContent = "  " + row.left.content;
            diffOutput.appendChild(div);
          }
        });
        diffOutput.style.color = "var(--ink)";
      } catch (e) {
        diffOutput.textContent = e.message;
        diffOutput.style.color = "var(--error)";
      }
    });
    const jwtInput = document.getElementById("jwt-input");
    const jwtHeader = document.getElementById("jwt-header-text");
    const jwtPayload = document.getElementById("jwt-payload-text");
    const jwtSignature = document.getElementById("jwt-signature-text");
    jwtInput.addEventListener("input", () => {
      const token = jwtInput.value.trim();
      if (!token) {
        jwtHeader.textContent = "";
        jwtPayload.textContent = "";
        jwtSignature.textContent = "";
        return;
      }
      const result = decodeJwtToken(token);
      if (result.validFormat) {
        jwtHeader.textContent = JSON.stringify(result.header, null, 2);
        jwtHeader.style.color = "var(--ink)";
        jwtPayload.textContent = JSON.stringify(result.payload, null, 2);
        jwtPayload.style.color = "var(--ink)";
        jwtSignature.textContent = result.signature || "";
        jwtSignature.style.color = "var(--ink)";
      } else {
        jwtHeader.textContent = "Invalid Token";
        jwtHeader.style.color = "var(--error)";
        jwtPayload.textContent = result.error || "Malformed JWT structure";
        jwtPayload.style.color = "var(--error)";
        jwtSignature.textContent = "";
      }
    });
    const base64Input = document.getElementById("base64-input");
    const base64Output = document.getElementById("base64-output-text");
    document.getElementById("base64-encode").addEventListener("click", () => {
      base64Output.textContent = encodeBase64(base64Input.value);
      base64Output.style.color = "var(--ink)";
    });
    document.getElementById("base64-decode").addEventListener("click", () => {
      try {
        base64Output.textContent = decodeBase64(base64Input.value);
        base64Output.style.color = "var(--ink)";
      } catch (e) {
        base64Output.textContent = "Invalid Base64 string.";
        base64Output.style.color = "var(--error)";
      }
    });
    const urlInput = document.getElementById("url-input");
    const urlOutput = document.getElementById("url-output-text");
    document.getElementById("url-encode").addEventListener("click", () => {
      urlOutput.textContent = encodeUrlString(urlInput.value);
      urlOutput.style.color = "var(--ink)";
    });
    document.getElementById("url-decode").addEventListener("click", () => {
      try {
        urlOutput.textContent = decodeUrlString(urlInput.value);
        urlOutput.style.color = "var(--ink)";
      } catch (e) {
        urlOutput.textContent = "Invalid URL encoding.";
        urlOutput.style.color = "var(--error)";
      }
    });
  });
})();
